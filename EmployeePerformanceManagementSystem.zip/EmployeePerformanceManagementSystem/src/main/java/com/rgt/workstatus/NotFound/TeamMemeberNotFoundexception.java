package com.rgt.workstatus.NotFound;

public class TeamMemeberNotFoundexception extends RuntimeException {

	public TeamMemeberNotFoundexception() {
		super();
	}

	public TeamMemeberNotFoundexception(String msg) {
		super(msg);
	}
}
