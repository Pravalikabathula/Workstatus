package com.rgt.workstatus.Domain;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Holidays {

	private Integer holidayId;
	private String holidayName;
	private Date holidayDate;
	private Boolean status;

	private Date createdDate;
	private String createdBy;
	private Date upadatedDate;
	private String updatedby;
}
