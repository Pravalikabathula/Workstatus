package com.rgt.workstatus.Domain;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Team {
	private Integer teamId;
	private String teamLeadName;
	private boolean status;
	private Date createdDate;
	private String createdBy;
	private Date upadatedDate;
	private String updatedby;

	private DepartmentDomain department;
	private Employee employee;

}
