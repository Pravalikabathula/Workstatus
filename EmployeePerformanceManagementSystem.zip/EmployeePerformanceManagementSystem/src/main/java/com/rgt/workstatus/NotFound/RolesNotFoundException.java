package com.rgt.workstatus.NotFound;

public class RolesNotFoundException extends RuntimeException {

	public RolesNotFoundException() {
		super();
	}

	public RolesNotFoundException(String msg) {
		super(msg);
	}
}
