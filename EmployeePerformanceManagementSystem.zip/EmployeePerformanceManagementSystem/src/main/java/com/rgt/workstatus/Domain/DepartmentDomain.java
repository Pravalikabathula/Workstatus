package com.rgt.workstatus.Domain;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class DepartmentDomain {

	private Integer departmentId;

	private String departmentName;

	private Boolean status;
	private Date createdDate;
	private String createdBy;
	private Date updateDate;
	private String updatedby;

//	private List<Employee> employee;

}