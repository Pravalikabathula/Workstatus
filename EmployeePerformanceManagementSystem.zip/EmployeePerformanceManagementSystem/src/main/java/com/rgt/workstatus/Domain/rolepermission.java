package com.rgt.workstatus.Domain;

import java.util.Date;

import com.rgt.workstatus.Entity.Permission;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class rolepermission {

	private Integer rolepermissionId;
	private Date createdDate;
	private Date upadatedDate;
	private String updatedby;

	private Permission Permission;
}
