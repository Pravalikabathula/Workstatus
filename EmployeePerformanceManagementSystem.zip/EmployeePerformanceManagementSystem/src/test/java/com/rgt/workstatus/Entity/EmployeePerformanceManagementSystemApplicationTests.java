package com.rgt.workstatus.Entity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeePerformanceManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
